import type { ProductResponse } from "./type";

export const fetchProducts = async () => {
  const res = await fetch("https://dummyjson.com/products");
  const data = await res.json();
  return data as ProductResponse;
}